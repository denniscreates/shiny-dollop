"use client"

import { useEffect, useState, useRef } from "react"
import { useLanguage } from "./language-provider"
import { useInView } from "react-intersection-observer"

export default function CounterSection() {
  const { t } = useLanguage()
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const [projectsCount, setProjectsCount] = useState(0)
  const [installationsCount, setInstallationsCount] = useState(0)
  const [clientsCount, setClientsCount] = useState(0)
  const [yearsCount, setYearsCount] = useState(0)

  const countersStarted = useRef(false)

  useEffect(() => {
    if (inView && !countersStarted.current) {
      countersStarted.current = true

      const projectsTarget = 5000
      const installationsTarget = 2000
      const clientsTarget = 7000
      const yearsTarget = 10

      const duration = 2000 // ms
      const frameDuration = 1000 / 60 // 60fps
      const totalFrames = Math.round(duration / frameDuration)

      let frame = 0
      const counter = setInterval(() => {
        frame++

        const progress = frame / totalFrames
        const easeOutQuad = 1 - (1 - progress) * (1 - progress)

        setProjectsCount(Math.floor(easeOutQuad * projectsTarget))
        setInstallationsCount(Math.floor(easeOutQuad * installationsTarget))
        setClientsCount(Math.floor(easeOutQuad * clientsTarget))
        setYearsCount(Math.floor(easeOutQuad * yearsTarget))

        if (frame === totalFrames) {
          clearInterval(counter)
        }
      }, frameDuration)

      return () => clearInterval(counter)
    }
  }, [inView])

  const stats = [
    { value: projectsCount, label: t("cadProjects") },
    { value: installationsCount, label: t("installations") },
    { value: clientsCount, label: t("happyClients") },
    { value: yearsCount, label: t("yearsExperience") },
  ]

  return (
    <section ref={ref} className="py-16 bg-gray-900 text-white">
      <div className="container">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {stats.map((stat, index) => (
            <div key={index} className="space-y-2">
              <div className="text-4xl md:text-5xl font-bold text-red-500">{stat.value.toLocaleString()}+</div>
              <p className="text-gray-300">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
