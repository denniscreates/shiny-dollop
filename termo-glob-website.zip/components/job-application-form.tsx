"use client"

import type React from "react"

import { useState } from "react"
import { useLanguage } from "./language-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Loader2, Upload } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import ReCAPTCHA from "react-google-recaptcha"

type JobOpening = {
  id: number
  title: string
  location: string
  type: string
  description: string
  requirements: string[]
}

export default function JobApplicationForm({ jobOpenings }: { jobOpenings: JobOpening[] }) {
  const { t } = useLanguage()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [captchaValue, setCaptchaValue] = useState<string | null>(null)
  const [fileName, setFileName] = useState<string>("")

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFileName(e.target.files[0].name)
    } else {
      setFileName("")
    }
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (!captchaValue) {
      toast({
        title: t("captchaRequired"),
        description: t("pleaseCompleteCaptcha"),
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // This would normally send to your Google Form
      const googleFormURL =
        "https://docs.google.com/forms/d/e/1FAIpQLScU0of88ZlW7baAHyFm6NmDROSBSwren_XIX2Ki57MU3y999g/formResponse"

      // In a real implementation, you would map your form fields to Google Form fields
      // For now, we'll simulate a successful submission
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: t("applicationSubmitted"),
        description: t("applicationThankYou"),
      })

      // Reset form
      ;(e.target as HTMLFormElement).reset()
      setCaptchaValue(null)
      setFileName("")
    } catch (error) {
      toast({
        title: t("errorOccurred"),
        description: t("pleaseTryAgain"),
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="position">{t("position")} *</Label>
        <Select name="position" required>
          <SelectTrigger>
            <SelectValue placeholder={t("selectPosition")} />
          </SelectTrigger>
          <SelectContent>
            {jobOpenings.map((job) => (
              <SelectItem key={job.id} value={job.id.toString()}>
                {job.title}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="firstName">{t("firstName")} *</Label>
          <Input id="firstName" name="firstName" required />
        </div>

        <div className="space-y-2">
          <Label htmlFor="lastName">{t("lastName")} *</Label>
          <Input id="lastName" name="lastName" required />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="email">{t("emailAddress")} *</Label>
          <Input id="email" name="email" type="email" required />
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone">{t("phoneNumber")} *</Label>
          <Input id="phone" name="phone" type="tel" required />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="address">{t("address")}</Label>
        <Input id="address" name="address" />
      </div>

      <div className="space-y-2">
        <Label>{t("education")} *</Label>
        <RadioGroup defaultValue="highSchool" name="education" required>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="highSchool" id="highSchool" />
            <Label htmlFor="highSchool">{t("highSchool")}</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="bachelors" id="bachelors" />
            <Label htmlFor="bachelors">{t("bachelors")}</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="masters" id="masters" />
            <Label htmlFor="masters">{t("masters")}</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="phd" id="phd" />
            <Label htmlFor="phd">{t("phd")}</Label>
          </div>
        </RadioGroup>
      </div>

      <div className="space-y-2">
        <Label htmlFor="experience">{t("workExperience")} *</Label>
        <Textarea id="experience" name="experience" rows={4} required />
      </div>

      <div className="space-y-2">
        <Label htmlFor="skills">{t("relevantSkills")} *</Label>
        <Textarea id="skills" name="skills" rows={3} required />
      </div>

      <div className="space-y-2">
        <Label htmlFor="resume" className="block mb-2">
          {t("uploadResume")} *
        </Label>
        <div className="flex items-center gap-4">
          <Button type="button" variant="outline" onClick={() => document.getElementById("resume")?.click()}>
            <Upload className="h-4 w-4 mr-2" />
            {t("chooseFile")}
          </Button>
          <Input
            id="resume"
            name="resume"
            type="file"
            accept=".pdf,.doc,.docx"
            required
            className="hidden"
            onChange={handleFileChange}
          />
          <span className="text-sm text-gray-500">{fileName ? fileName : t("noFileChosen")}</span>
        </div>
        <p className="text-xs text-gray-500 mt-1">{t("acceptedFileTypes")}: PDF, DOC, DOCX</p>
      </div>

      <div className="space-y-2">
        <div className="flex items-start space-x-2">
          <Checkbox id="terms" name="terms" required />
          <Label htmlFor="terms" className="text-sm">
            {t("termsAgreement")}
          </Label>
        </div>
      </div>

      <div className="flex justify-center my-6">
        <ReCAPTCHA
          sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI" // This is a test key
          onChange={(value) => setCaptchaValue(value)}
        />
      </div>

      <Button type="submit" className="w-full" disabled={isSubmitting || !captchaValue}>
        {isSubmitting ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            {t("submitting")}
          </>
        ) : (
          t("submitApplication")
        )}
      </Button>
    </form>
  )
}
