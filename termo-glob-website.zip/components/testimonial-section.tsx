"use client"

import { useLanguage } from "./language-provider"
import { Card, CardContent } from "@/components/ui/card"
import { Quote } from "lucide-react"
import { useState } from "react"

export default function TestimonialSection() {
  const { t } = useLanguage()
  const [activeIndex, setActiveIndex] = useState(0)

  const testimonials = [
    {
      quote: t("testimonial1"),
      author: t("testimonialAuthor1"),
      position: t("testimonialPosition1"),
    },
    {
      quote: t("testimonial2"),
      author: t("testimonialAuthor2"),
      position: t("testimonialPosition2"),
    },
    {
      quote: t("testimonial3"),
      author: t("testimonialAuthor3"),
      position: t("testimonialPosition3"),
    },
  ]

  return (
    <section className="py-20 bg-gray-50">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">{t("testimonialTitle")}</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">{t("testimonialSubtitle")}</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="border-none shadow-lg">
            <CardContent className="pt-10 pb-10">
              <div className="flex justify-center mb-6">
                <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                  <Quote className="h-6 w-6 text-red-600" />
                </div>
              </div>

              <blockquote className="text-center text-xl italic mb-6 text-gray-800">
                "{testimonials[activeIndex].quote}"
              </blockquote>

              <div className="text-center">
                <div className="font-semibold text-gray-800">{testimonials[activeIndex].author}</div>
                <div className="text-gray-600 text-sm">{testimonials[activeIndex].position}</div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`w-3 h-3 rounded-full ${index === activeIndex ? "bg-red-600" : "bg-gray-300"}`}
                aria-label={`Testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
