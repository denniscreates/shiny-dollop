"use client"
import { useLanguage } from "@/components/language-provider"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Phone, Clock } from "lucide-react"
import ContactForm from "@/components/contact-form"

export default function ContactPage() {
  const { t } = useLanguage()

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gray-900 text-white py-20">
        <div className="container text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">{t("contactUsTitle")}</h1>
          <p className="text-xl max-w-2xl mx-auto">{t("contactUsSubtitle")}</p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="text-center pb-2">
                <div className="mx-auto w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mb-4">
                  <MapPin className="h-6 w-6 text-red-600" />
                </div>
                <CardTitle>{t("ourLocation")}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600">Xheladin Hana, Prishtina, Kosova</p>
                <div className="mt-4">
                  <a
                    href="https://maps.app.goo.gl/jdVd3URMUWfwWwVX6"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-red-600 hover:underline"
                  >
                    {t("viewOnMap")}
                  </a>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="text-center pb-2">
                <div className="mx-auto w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <Phone className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>{t("phoneEmail")}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 mb-2">
                  <a href="tel:+38344239177" className="hover:text-blue-600">
                    +383 44 239 177
                  </a>
                </p>
                <p className="text-gray-600">
                  <a href="mailto:info@termoglob.net" className="hover:text-blue-600">
                    info@termoglob.net
                  </a>
                </p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="text-center pb-2">
                <div className="mx-auto w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <Clock className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle>{t("businessHours")}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 mb-2">{t("mondayFriday")}: 9:00 - 17:00</p>
                <p className="text-gray-600">
                  {t("saturdaySunday")}: {t("closed")}
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold mb-6">{t("getInTouch")}</h2>
              <p className="text-gray-600 mb-8">{t("contactFormDescription")}</p>

              <ContactForm />
            </div>

            <div className="h-[500px] rounded-lg overflow-hidden shadow-lg">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2934.5!2d21.1516!3d42.6486!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDLCsDM4JzU1LjAiTiAyMcKwMDknMDUuOCJF!5e0!3m2!1sen!2s!4v1713881234567!5m2!1sen!2s"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Termo Glob Location - Prishtina, Kosovo"
              ></iframe>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
