"use client"

import { useLanguage } from "@/components/language-provider"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ProjectsPage() {
  const { t } = useLanguage()

  const projects = [
    {
      id: 1,
      title: "Commercial Office HVAC Installation",
      category: "commercial",
      image: "/images/hvac-industrial.jpeg",
      description: "Complete HVAC system installation for a 10-story office building in Prishtina.",
      year: "2023",
    },
    {
      id: 2,
      title: "Residential Complex Heating System",
      category: "residential",
      image: "/images/hvac-technician.jpeg",
      description: "Design and installation of central heating systems for a 50-unit residential complex.",
      year: "2022",
    },
    {
      id: 3,
      title: "Shopping Mall Air Conditioning",
      category: "commercial",
      image: "/images/ac-unit.jpeg",
      description: "Large-scale air conditioning system for a major shopping center in Kosovo.",
      year: "2023",
    },
    {
      id: 4,
      title: "Hospital HVAC System Upgrade",
      category: "healthcare",
      image: "/images/hvac-industrial.jpeg",
      description: "Modernization of existing HVAC systems for improved air quality and energy efficiency.",
      year: "2021",
    },
    {
      id: 5,
      title: "Hotel Climate Control System",
      category: "hospitality",
      image: "/images/hvac-technician.jpeg",
      description: "Comprehensive climate control solution for a luxury hotel with 120 rooms.",
      year: "2022",
    },
    {
      id: 6,
      title: "Residential Villa HVAC Design",
      category: "residential",
      image: "/images/ac-unit.jpeg",
      description: "Custom HVAC design and installation for a high-end residential villa.",
      year: "2023",
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gray-900 text-white py-20">
        <div className="container text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">{t("ourProjects")}</h1>
          <p className="text-xl max-w-2xl mx-auto">{t("projectsSubtitle")}</p>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">{t("featuredProjects")}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("featuredProjectsDesc")}</p>
          </div>

          <Tabs defaultValue="all" className="w-full mb-12">
            <div className="flex justify-center mb-8">
              <TabsList>
                <TabsTrigger value="all">{t("allProjects")}</TabsTrigger>
                <TabsTrigger value="commercial">{t("commercial")}</TabsTrigger>
                <TabsTrigger value="residential">{t("residential")}</TabsTrigger>
                <TabsTrigger value="healthcare">{t("healthcare")}</TabsTrigger>
                <TabsTrigger value="hospitality">{t("hospitality")}</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="all">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects.map((project) => (
                  <ProjectCard key={project.id} project={project} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="commercial">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === "commercial")
                  .map((project) => (
                    <ProjectCard key={project.id} project={project} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="residential">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === "residential")
                  .map((project) => (
                    <ProjectCard key={project.id} project={project} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="healthcare">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === "healthcare")
                  .map((project) => (
                    <ProjectCard key={project.id} project={project} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="hospitality">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === "hospitality")
                  .map((project) => (
                    <ProjectCard key={project.id} project={project} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Project Process */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">{t("ourProjectProcess")}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("projectProcessDesc")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mb-4 mx-auto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-red-600"
                >
                  <path d="M2 12a10 10 0 1 0 20 0 10 10 0 1 0-20 0Z" />
                  <path d="M12 8v4l2 2" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">{t("consultation")}</h3>
              <p className="text-gray-600">{t("consultationDesc")}</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4 mx-auto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-blue-600"
                >
                  <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">{t("design")}</h3>
              <p className="text-gray-600">{t("designDesc")}</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4 mx-auto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-green-600"
                >
                  <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
                  <path d="M3.29 7 12 12l8.71-5" />
                  <path d="M12 22V12" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">{t("installation")}</h3>
              <p className="text-gray-600">{t("installationDesc")}</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mb-4 mx-auto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-purple-600"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                  <path d="m9 12 2 2 4-4" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">{t("maintenance")}</h3>
              <p className="text-gray-600">{t("maintenanceDesc")}</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-red-600 text-white">
        <div className="container text-center">
          <h2 className="text-3xl font-bold mb-4">{t("startYourProject")}</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8">{t("startYourProjectDesc")}</p>
          <Button asChild size="lg" className="bg-white text-red-600 hover:bg-gray-100">
            <a href="/contact">{t("contactUs")}</a>
          </Button>
        </div>
      </section>
    </div>
  )
}

function ProjectCard({ project }: { project: any }) {
  return (
    <Card className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-shadow">
      <div className="relative h-48">
        <Image src={project.image || "/placeholder.svg"} alt={project.title} fill className="object-cover" />
      </div>
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium bg-gray-100 px-2 py-1 rounded">{project.category}</span>
          <span className="text-sm text-gray-500">{project.year}</span>
        </div>
        <h3 className="text-xl font-bold mb-2">{project.title}</h3>
        <p className="text-gray-600 mb-4">{project.description}</p>
        <Button variant="outline" className="w-full">
          View Details
        </Button>
      </CardContent>
    </Card>
  )
}
