"use client"

import { useLanguage } from "@/components/language-provider"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function ServicesPage() {
  const { t } = useLanguage()

  const services = [
    {
      id: 1,
      title: t("hvacProducts"),
      description: t("hvacProductsDesc"),
      image: "/images/ac-unit.jpeg",
      features: [
        t("hvacProductFeature1"),
        t("hvacProductFeature2"),
        t("hvacProductFeature3"),
        "Energy-saving models from top brands",
        "Smart climate control systems",
        "Full range of heating and cooling solutions",
      ],
    },
    {
      id: 2,
      title: t("hvacInstallation"),
      description: t("hvacInstallationDesc"),
      image: "/images/hvac-technician.jpeg",
      features: [
        t("hvacInstallFeature1"),
        t("hvacInstallFeature2"),
        t("hvacInstallFeature3"),
        "Professional system setup and configuration",
        "Compliance with all safety regulations",
        "Post-installation support and guidance",
      ],
    },
    {
      id: 3,
      title: t("cadProjects"),
      description: t("cadProjectsDesc"),
      image: "/images/hvac-industrial.jpeg",
      features: [
        t("cadFeature1"),
        t("cadFeature2"),
        t("cadFeature3"),
        "Custom design for residential and commercial buildings",
        "Energy efficiency optimization",
        "Detailed documentation and specifications",
      ],
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gray-900 text-white py-20">
        <div className="container text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">{t("ourServices")}</h1>
          <p className="text-xl max-w-2xl mx-auto">{t("servicesSubtitle")}</p>
        </div>
      </section>

      {/* Services Detail */}
      <section className="py-20">
        <div className="container">
          <div className="space-y-20">
            {services.map((service, index) => (
              <div
                key={service.id}
                className={`grid grid-cols-1 md:grid-cols-2 gap-12 items-center ${
                  index % 2 === 1 ? "md:flex-row-reverse" : ""
                }`}
              >
                <div className={index % 2 === 1 ? "md:order-2" : ""}>
                  <h2 className="text-3xl font-bold mb-4">{service.title}</h2>
                  <p className="text-gray-600 mb-6">{service.description}</p>

                  <div className="space-y-3">
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div
                  className={`relative h-[400px] rounded-lg overflow-hidden shadow-xl ${index % 2 === 1 ? "md:order-1" : ""}`}
                >
                  <Image src={service.image || "/placeholder.svg"} alt={service.title} fill className="object-cover" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">{t("whyChooseUs")}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("whyChooseUsDesc")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-none shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-red-600"
                    >
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                      <path d="m14.5 9-5 5" />
                      <path d="m9.5 9 5 5" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{t("experiencedTeam")}</h3>
                  <p className="text-gray-600">{t("experiencedTeamDesc")}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-blue-600"
                    >
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                      <path d="M12 8v4" />
                      <path d="M12 16h.01" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{t("qualityGuarantee")}</h3>
                  <p className="text-gray-600">{t("qualityGuaranteeDesc")}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-600"
                    >
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                      <path d="M9.1 12a2.1 2.1 0 0 1 0 2.2" />
                      <path d="M14.9 12a2.1 2.1 0 0 0 0 2.2" />
                      <path d="M12 13a1 1 0 0 0 0 1" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{t("customerSupport")}</h3>
                  <p className="text-gray-600">{t("customerSupportDesc")}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Add a proper button at the bottom of the page for better navigation */}
      <section className="py-16 bg-red-600 text-white">
        <div className="container text-center">
          <h2 className="text-3xl font-bold mb-4">{t("readyToStart")}</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8">{t("contactUsForQuote")}</p>
          <Button asChild size="lg" className="bg-white text-red-600 hover:bg-gray-100 font-bold">
            <Link href="/contact">{t("getQuote")}</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
