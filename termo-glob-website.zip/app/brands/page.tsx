"use client"

import { useLanguage } from "@/components/language-provider"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"

export default function BrandsPage() {
  const { t } = useLanguage()

  const brands = [
    { name: "LG", logo: "/images/brands/lg.png", description: t("lgDescription") },
    { name: "Samsung", logo: "/images/brands/samsung.png", description: t("samsungDescription") },
    { name: "Daikin", logo: "/images/brands/daikin.png", description: t("daikinDescription") },
    { name: "Vivax", logo: "/images/brands/vivax.png", description: t("vivaxDescription") },
    { name: "Mitsubishi Electric", logo: "/images/brands/mitsubishi.png", description: t("mitsubishiDescription") },
    { name: "Gree", logo: "/images/brands/gree.png", description: t("greeDescription") },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gray-900 text-white py-20">
        <div className="container text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">{t("ourBrands")}</h1>
          <p className="text-xl max-w-2xl mx-auto">{t("brandsSubtitle")}</p>
        </div>
      </section>

      {/* Brands Grid */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">{t("trustedPartners")}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("partnersDescription")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {brands.map((brand) => (
              <Card
                key={brand.name}
                className="border-none shadow-lg hover:shadow-xl transition-shadow overflow-hidden"
              >
                <CardContent className="p-6">
                  <div className="flex flex-col items-center">
                    <div className="h-32 w-full relative mb-6 flex items-center justify-center bg-white p-4 rounded">
                      <Image
                        src={brand.logo || "/placeholder.svg"}
                        alt={`${brand.name} Logo`}
                        width={150}
                        height={80}
                        className="object-contain"
                      />
                    </div>
                    <h3 className="text-xl font-bold mb-3">{brand.name}</h3>
                    <p className="text-gray-600 text-center">{brand.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Our Brands */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">{t("whyChooseOurBrands")}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("brandsAdvantages")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mb-4 mx-auto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-red-600"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3 text-center">{t("qualityAssurance")}</h3>
              <p className="text-gray-600 text-center">{t("qualityAssuranceDesc")}</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4 mx-auto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-blue-600"
                >
                  <path d="M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />
                  <path d="M12 8v-2" />
                  <path d="M12 18v-2" />
                  <path d="M16 12h2" />
                  <path d="M6 12h2" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3 text-center">{t("energyEfficiency")}</h3>
              <p className="text-gray-600 text-center">{t("energyEfficiencyDesc")}</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4 mx-auto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-green-600"
                >
                  <path d="M21 12a9 9 0 0 1-9 9m9-9a9 9 0 0 0-9-9m9 9H3m9 9a9 9 0 0 1-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3 text-center">{t("globalSupport")}</h3>
              <p className="text-gray-600 text-center">{t("globalSupportDesc")}</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
